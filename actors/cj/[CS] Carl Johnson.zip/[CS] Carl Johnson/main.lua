-- name: [CS] Carl Johnson
-- description: Ah shit! Here we go again!\n\nMod by: \\#19f505\\MrMarco1003\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation

    Use this if you're curious on how anything here works >v<
]]

local TEXT_MOD_NAME = "Carl Johnson"

-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_CUSTOM_MODEL = smlua_model_util_get_id("cj_geo") -- Located in "actors"

local TEX_CUSTOM_LIFE_ICON = get_texture_info("cj_icon") -- Located in "textures"

-- All Located in "sound"
local VOICETABLE_CARLJ = {
    [CHAR_SOUND_OKEY_DOKEY] = 'CJStartGame.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] = 'CJStartLevel.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] = 'CJPunchYah.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] = 'CJPunchWah.ogg', -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] = 'CJPunchHoo.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] = {'CJJump1.ogg', 'CJJump2.ogg', 'CJJump3.ogg'}, -- First/Second jump sounds
	[CHAR_SOUND_HOOHOO] = 'CJDoubleJump.ogg', -- Third jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'CJTripleYahoo.ogg', 'CJTripleWaha.ogg', "CJTripleYippee.ogg"}, -- Triple jump sounds
	[CHAR_SOUND_UH] = 'CJBonkUh.ogg', -- Wall bonk
	[CHAR_SOUND_UH2] = 'CJUh2.ogg', -- Landing after long jump
	[CHAR_SOUND_UH2_2] = 'CJUh2Ledge.ogg', -- Same sound as UH2; jumping onto ledge
	[CHAR_SOUND_HAHA] = 'CJTripleLand.ogg', -- Landing triple jump
	[CHAR_SOUND_YAHOO] = 'CJTripleYahoo.ogg', -- Long jump
	[CHAR_SOUND_DOH] = 'CJBonkDoh.ogg', -- Long jump wall bonk
	[CHAR_SOUND_WHOA] = 'CJGrabLedge.ogg', -- Grabbing ledge
	[CHAR_SOUND_EEUH] = 'CJClimbLedge.ogg', -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] = 'CJFalling.ogg', -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] = 'CJTwirlBounce.ogg', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] = 'CJGroundPound.ogg', 
	[CHAR_SOUND_HRMM] = 'CJLift.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] = 'CJStarGet.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] = 'CJThrowBowser.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] = 'CJDamaged.ogg', -- Damaged
	[CHAR_SOUND_PANTING] = 'CJPanting.ogg', -- Low health
	[CHAR_SOUND_ON_FIRE] = 'CJOnFire.ogg', -- Burned
--SLEEP SOUNDS
	[CHAR_SOUND_IMA_TIRED] = 'CJTired.ogg', -- Mario feeling tired
	[CHAR_SOUND_YAWNING] = 'CJYawning.ogg', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] = 'CJMute.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] = 'CJMute.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] = 'CJDreaming.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] = 'CJCoughing1.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] = 'CJCoughing2.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] = 'CJCoughing3.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] = 'CJDyingDamage.ogg', -- Dying from damage
	[CHAR_SOUND_DROWNING] = 'CJDrowning.ogg', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] = 'CJMammaMia.ogg' -- Booted out of level
}

-- All Located in "actors"
local CAPTABLE_CHAR = {
    normal = smlua_model_util_get_id("cj_capnormal_geo"),
    wing = smlua_model_util_get_id("cj_wingcap_geo"),
    metal = smlua_model_util_get_id("cj_metalcap_geo"),
}

local PALETTE_CHAR = {
    [PANTS]  = "2c3d59",
    [SHIRT]  = "bec0d3",
    [GLOVES] = "ffffff",
    [SHOES]  = "181818",
    [HAIR]   = "ffffff",
    [SKIN]   = "ffffff",
    [CAP]    = "ffffff",
}


-- All Located in "textures"
local healthCarlJ = {
    label = {
        left = get_texture_info("LeftHealth_CJ"),
        right = get_texture_info("RightHealth_CJ"),
    },
     pie = {
        [1] = get_texture_info("CJPie1"),
        [2] = get_texture_info("CJPie2"),
        [3] = get_texture_info("CJPie3"),
        [4] = get_texture_info("CJPie4"),
        [5] = get_texture_info("CJPie5"),
        [6] = get_texture_info("CJPie6"),
        [7] = get_texture_info("CJPie7"),
        [8] = get_texture_info("CJPie8"),
    }
}


--[[
    Note: If there are some functionalities you don't care
    to add such as palettes, you can freely remove the function
    for it, the only function you require is character_add
]]

local CSloaded = false
local function on_character_select_load()
    CT_CHAR = _G.charSelect.character_add("Carl Johnson", {"Ah shit! Here we go again!", "Carl Johnson or by short 'CJ' is an main", "protagonist of Grand Theft Auto: San Andreas game.", "Model from GTA: San Andreas"}, "MrMarco1003", {r = 14, g = 230, b = 25}, E_MODEL_CUSTOM_MODEL, CT_MARIO, TEX_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_CUSTOM_MODEL, CAPTABLE_CHAR)
    _G.charSelect.character_add_voice(E_MODEL_CUSTOM_MODEL, VOICETABLE_CARLJ)
    _G.charSelect.character_add_celebration_star(E_MODEL_CUSTOM_MODEL, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_CUSTOM_MODEL, PALETTE_CHAR)
    _G.charSelect.character_add_health_meter(CT_CHAR, healthCarlJ)

    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_CARLJ then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_CARLJ then return _G.charSelect.voice.snore(m) end
end

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)
