#!/usr/bin/env python3
"""Import prepared CJ GLB in Blender 3.6 and export the static DynOS actor with Fast64."""
from __future__ import annotations
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path
from mathutils import Matrix  # type: ignore
import bpy  # type: ignore


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def main():
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(args) != 3:
        raise SystemExit("usage: export_cj_static_actor.py <prepared.glb> <repo_root> <output_dir>")
    glb, repo_root, output = [Path(x).resolve() for x in args]
    require(glb.is_file(), f"Prepared GLB missing: {glb}")
    require((repo_root / "main.lua").is_file(), "Repo root missing main.lua")

    fast64_root = Path(os.environ.get("FAST64_ADDON_PATH", "")).resolve()
    require((fast64_root / "__init__.py").is_file(), "FAST64_ADDON_PATH is not configured")
    sys.path.insert(0, str(fast64_root.parent))
    import fast64  # type: ignore
    fast64.register()
    try:
        bpy.ops.preferences.addon_enable(module="io_scene_gltf2")
    except Exception:
        pass
    require(hasattr(bpy.ops.import_scene, "gltf"), "Blender 3.6 glTF importer is unavailable")
    bpy.ops.import_scene.gltf(filepath=str(glb))
    meshes = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    require(len(meshes) >= 1, "The prepared GLB contains no mesh")

    # Bake node transforms before joining to get one static mesh at identity.
    for obj in meshes:
        world = obj.matrix_world.copy()
        for vertex in obj.data.vertices:
            vertex.co = world @ vertex.co
        obj.matrix_world = Matrix.Identity(4)
        obj.parent = None
        for modifier in list(obj.modifiers):
            obj.modifiers.remove(modifier)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    if len(meshes) > 1:
        bpy.ops.object.join()
    obj = bpy.context.view_layer.objects.active
    obj.name = "CJ_Static_Model_Test"

    def ensure_base_color_texture(material):
        """Fast64 requires every F3D material to own a texture.

        Preserve source image textures. For a source material with no image
        (the FBX has one untextured material slot), generate a tiny solid-color
        image sampled from its original Principled Base Color/diffuse color.
        This avoids silently reusing an unrelated body texture for the eyes.
        """
        if material is None:
            return False
        material.use_nodes = True
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        principled = next((n for n in nodes if n.type == "BSDF_PRINCIPLED"), None)
        if principled is None:
            principled = nodes.new("ShaderNodeBsdfPrincipled")
            output_node = next((n for n in nodes if n.type == "OUTPUT_MATERIAL"), None)
            if output_node is None:
                output_node = nodes.new("ShaderNodeOutputMaterial")
            links.new(principled.outputs["BSDF"], output_node.inputs["Surface"])
        base_color = principled.inputs.get("Base Color")
        if base_color is None:
            raise RuntimeError(f"Material {material.name} has no Principled Base Color input")
        for connection in base_color.links:
            source = connection.from_node
            if source.type == "TEX_IMAGE" and source.image is not None:
                return False
        rgba = tuple(float(v) for v in base_color.default_value)
        if len(rgba) != 4:
            rgba = tuple(float(v) for v in material.diffuse_color)
        rgba = tuple(min(1.0, max(0.0, v)) for v in rgba)
        image = bpy.data.images.new(
            name=f"CJ64_{material.name}_solid_fallback",
            width=4,
            height=4,
            alpha=True,
            float_buffer=False,
        )
        image.pixels = list(rgba) * 16
        image.pack()
        tex_node = nodes.new("ShaderNodeTexImage")
        tex_node.name = f"CJ64_{material.name}_solid_fallback_texture"
        tex_node.label = "CJ64 generated solid-color fallback"
        tex_node.image = image
        links.new(tex_node.outputs["Color"], base_color)
        return True

    fallback_materials = [
        material.name for material in obj.data.materials
        if ensure_base_color_texture(material)
    ]

    import fast64.fast64_internal.f3d_material_converter as material_converter  # type: ignore
    material_converter.convertAllBSDFtoF3D([obj], True)
    unresolved = [m.name for m in obj.data.materials if m and not bool(getattr(m, "is_f3d", False))]
    require(not unresolved, f"Fast64 could not convert materials: {unresolved}")

    output.mkdir(parents=True, exist_ok=True)
    mod_root = output / "CJ64-Model-Test"
    actors_dir = mod_root / "actors"
    actors_dir.mkdir(parents=True, exist_ok=True)
    scene = bpy.context.scene
    scene.gameEditorMode = "SM64"
    scene.fast64.sm64.exportType = "C"
    scene.saveTextures = True
    scene.geoSeparateTextureDef = False
    scene.geoCustomExport = True
    scene.geoExportPath = str(actors_dir)
    scene.geoTexDir = "actors/cj/"
    scene.geoName = "cj"
    scene.geoStructName = "cj_geo"
    scene.geoGroupName = "group0"
    scene.geoExportHeaderType = "Actor"
    scene.geoDeleteOldGeo = True
    scene.exportInlineF3D = False
    scene.blenderToSM64Scale = 100.0
    obj.geo_cmd_static = "Optimal"
    obj.draw_layer_static = "1"
    obj.use_render_area = False
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode="OBJECT")
    result = bpy.ops.object.sm64_export_geolayout_object()
    require("FINISHED" in result, f"Fast64 actor export did not finish: {result}")

    actor_dir = actors_dir / "cj"
    required = ["geo.inc.c", "model.inc.c", "geo_header.h"]
    missing = [name for name in required if not (actor_dir / name).is_file()]
    require(not missing, f"Fast64 did not produce actor files: {missing}")
    shutil.copy2(repo_root / "main.lua", mod_root / "main.lua")
    shutil.copy2(repo_root / "character.lua", mod_root / "character.lua")
    (mod_root / "README-INSTALL.txt").write_text("""CJ64 — static model visibility test

Copy this CJ64-Model-Test folder into SM64CoopDX/mods/ and enable the CJ64
Lua mod. The first launch builds the actor binary from the C GeoLayout files
inside actors/cj/. The mod replaces only the visible model on the existing
marioObj. MarioState, movement, collision, camera and physics are retained.

LIMITATION: this is a static rest-pose mesh. It does not use Mario's armature,
so limbs will not follow Mario's animations yet. This test only checks model
loading, orientation, shape and textures. Do not use it as the final character.

Source model: Carl Johnson (CJ) by Tsaphnat (Tsaphnat Mbuyi), Sketchfab, CC BY 4.0.
https://sketchfab.com/3d-models/carl-johnson-cj-647f5417720344cb8c2079edd48704ac
""", encoding="utf-8")
    (actor_dir / "README.md").write_text("Static CJ model test actor. Runtime GeoLayout symbol: cj_geo. No skinning/animation yet.\n", encoding="utf-8")

    files = []
    for path in sorted(actor_dir.rglob("*")):
        if path.is_file():
            files.append({"path": str(path.relative_to(mod_root)), "size": path.stat().st_size})
    report = {
        "format": "cj64-static-model-test-v1",
        "status": "EXPORTED_NOT_YET_TESTED_IN_GAME",
        "model_name": "cj_geo",
        "animation_mode": "STATIC_REST_POSE",
        "keeps_native_mario_object": True,
        "keeps_native_mariostate_physics_collision_camera": True,
        "vertex_count": len(obj.data.vertices),
        "polygon_count": len(obj.data.polygons),
        "material_names": [m.name if m else None for m in obj.data.materials],
        "generated_solid_fallback_materials": fallback_materials,
        "actor_files": files,
        "warnings": [
            "Static rest-pose model only; no Mario Armature weights/animation.",
            "In-game visibility has not yet been tested on the user's installation.",
        ],
    }
    (output / "cj_model_test_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    archive = output / "CJ64-Model-Test.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=8) as zf:
        for path in sorted(mod_root.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(mod_root.parent))
    print(json.dumps({"package": str(archive), "report": report}, indent=2))


if __name__ == "__main__":
    main()
