#!/usr/bin/env python3
"""Build a first static CJ actor package for an in-game SM64CoopDX visibility test.

This deliberately bakes the source FBX skin at its rest pose and exports one
static DynOS GeoLayout. It is not the final Mario-armature rig and has no limb
animation. The test isolates mesh orientation, texture conversion, GeoLayout
compilation and native marioObj model replacement.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

import bpy  # type: ignore
import bmesh  # type: ignore
from mathutils import Matrix, Vector  # type: ignore


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def get_source_asset(path: Path):
    bpy.ops.wm.fbx_import(
        filepath=str(path),
        use_anim=False,
        use_custom_props=True,
        ignore_leaf_bones=False,
        validate_meshes=True,
    )
    armatures = [o for o in bpy.context.scene.objects if o.type == "ARMATURE"]
    meshes = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    require(len(armatures) == 1, f"Expected exactly one source armature; found {len(armatures)}")
    require(len(meshes) >= 1, "The CJ FBX importer did not produce any mesh objects")
    meshes.sort(key=lambda obj: obj.name.casefold())
    print("CJ FBX mesh objects:", [(obj.name, len(obj.data.vertices), len(obj.data.polygons)) for obj in meshes])
    return armatures[0], meshes


def bake_source_rest_meshes(source_armature, source_meshes):
    """Bake every FBX mesh at the rest pose and join without losing material slots."""
    source_armature.data.pose_position = "REST"
    bpy.context.scene.frame_set(0)
    bpy.context.view_layer.update()

    baked_objects = []
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for source_mesh in source_meshes:
        evaluated = source_mesh.evaluated_get(depsgraph)
        mesh_data = bpy.data.meshes.new_from_object(
            evaluated,
            preserve_all_data_layers=True,
            depsgraph=depsgraph,
        )
        require(mesh_data is not None and len(mesh_data.vertices) > 0,
                f"FBX mesh {source_mesh.name!r} produced empty evaluated geometry")

        baked = bpy.data.objects.new("CJ_Baked__" + source_mesh.name, mesh_data)
        bpy.context.scene.collection.objects.link(baked)
        baked.matrix_world = source_mesh.matrix_world.copy()

        # Apply the FBX object/parent transforms to vertices before joining.
        world_matrix = baked.matrix_world.copy()
        for vertex in baked.data.vertices:
            vertex.co = world_matrix @ vertex.co
        baked.matrix_world = Matrix.Identity(4)
        baked.parent = None
        for modifier in list(baked.modifiers):
            baked.modifiers.remove(modifier)
        while len(baked.vertex_groups):
            baked.vertex_groups.remove(baked.vertex_groups[0])
        baked.data.update()
        baked_objects.append(baked)

    bpy.ops.object.select_all(action="DESELECT")
    for baked in baked_objects:
        baked.select_set(True)
    bpy.context.view_layer.objects.active = baked_objects[0]
    if len(baked_objects) > 1:
        bpy.ops.object.join()
    result = bpy.context.view_layer.objects.active
    result.name = "CJ_Static_Model_Test"

    bm = bmesh.new()
    bm.from_mesh(result.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(result.data)
    bm.free()
    result.data.update()
    return result


def align_and_size_model(obj, source_armature, target_height=1.60):
    """Align the FBX root-to-head vector to Blender Z-up and place the feet at Z=0."""
    root = source_armature.data.bones.get("root ground")
    head = source_armature.data.bones.get("head neck upper")
    require(root is not None and head is not None, "The CJ FBX is missing root ground or head neck upper")

    root_world = source_armature.matrix_world @ root.head_local
    head_world = source_armature.matrix_world @ head.head_local
    up_vector = head_world - root_world
    require(up_vector.length > 0.25, "CJ source skeleton has an invalid root-to-head vector")
    align = up_vector.normalized().rotation_difference(Vector((0.0, 0.0, 1.0)))

    for vertex in obj.data.vertices:
        vertex.co = align @ (vertex.co - root_world)

    coords = [vertex.co for vertex in obj.data.vertices]
    min_z = min(v.z for v in coords)
    max_z = max(v.z for v in coords)
    height = max_z - min_z
    require(height > 0.5, f"Unexpected CJ height after axis alignment: {height:.4f}")

    factor = float(target_height) / height
    for vertex in obj.data.vertices:
        vertex.co *= factor

    coords = [vertex.co for vertex in obj.data.vertices]
    min_x = min(v.x for v in coords)
    max_x = max(v.x for v in coords)
    min_y = min(v.y for v in coords)
    max_y = max(v.y for v in coords)
    min_z = min(v.z for v in coords)
    offset = Vector((
        -0.5 * (min_x + max_x),
        -0.5 * (min_y + max_y),
        -min_z,
    ))
    for vertex in obj.data.vertices:
        vertex.co += offset

    obj.data.update()
    bpy.context.view_layer.update()
    dims = [round(float(x), 5) for x in obj.dimensions]
    require(obj.dimensions.z > obj.dimensions.x * 0.55, f"CJ does not appear upright after alignment: {dims}")
    return {
        "source_root_world": [round(float(v), 6) for v in root_world],
        "source_head_world": [round(float(v), 6) for v in head_world],
        "source_height": round(float(height), 6),
        "applied_scale": round(float(factor), 6),
        "target_height": round(float(target_height), 6),
        "final_dimensions": dims,
    }


def render_preview(obj, output_path: Path):
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x = 800
    scene.render.resolution_y = 900
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "Medium High Contrast"
    scene.view_settings.exposure = 0.0
    scene.view_settings.gamma = 1.0

    world = bpy.data.worlds.new("CJ Preview World") if scene.world is None else scene.world
    scene.world = world
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.055, 0.065, 0.085, 1.0)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.8

    center = Vector((0.0, 0.0, 0.82))
    camera_data = bpy.data.cameras.new("CJ Preview Camera")
    camera = bpy.data.objects.new("CJ Preview Camera", camera_data)
    scene.collection.objects.link(camera)
    camera.location = (2.65, -4.8, 2.15)
    camera_data.type = "ORTHO"
    camera_data.ortho_scale = 2.85
    direction = center - camera.location
    camera.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    scene.camera = camera

    def area_light(name, location, power, size):
        data = bpy.data.lights.new(name, "AREA")
        data.energy = power
        data.shape = "DISK"
        data.size = size
        light = bpy.data.objects.new(name, data)
        scene.collection.objects.link(light)
        light.location = location
        light.rotation_euler = (center - light.location).to_track_quat("-Z", "Y").to_euler()
        return light

    lights = [
        area_light("Key", (3.0, -4.0, 4.2), 650, 4.0),
        area_light("Fill", (-3.5, -2.0, 2.4), 350, 3.2),
        area_light("Rim", (0.5, 3.5, 3.5), 700, 3.0),
    ]

    floor_mesh = bpy.data.meshes.new("Preview Floor Mesh")
    floor_mesh.from_pydata(
        [(-4, -4, -0.015), (4, -4, -0.015), (4, 4, -0.015), (-4, 4, -0.015)],
        [],
        [(0, 1, 2, 3)],
    )
    floor = bpy.data.objects.new("Preview Floor", floor_mesh)
    scene.collection.objects.link(floor)
    floor_mat = bpy.data.materials.new("Preview Floor Material")
    floor_mat.diffuse_color = (0.08, 0.09, 0.11, 1.0)
    floor.data.materials.append(floor_mat)

    scene.render.filepath = str(output_path)
    bpy.ops.render.render(write_still=True)

    bpy.data.objects.remove(floor, do_unlink=True)
    bpy.data.objects.remove(camera, do_unlink=True)
    for light in lights:
        bpy.data.objects.remove(light, do_unlink=True)
    scene.camera = None


def find_base_color_image(material):
    if material is None or not material.use_nodes or material.node_tree is None:
        return None
    for node in material.node_tree.nodes:
        if node.type != "BSDF_PRINCIPLED":
            continue
        socket = node.inputs.get("Base Color")
        if socket is None:
            continue
        for link in socket.links:
            source = link.from_node
            if source.type == "TEX_IMAGE" and source.image is not None:
                return source.image
    # Some FBX importers connect the image through an intermediate node.
    for node in material.node_tree.nodes:
        if node.type == "TEX_IMAGE" and node.image is not None:
            return node.image
    return None


def convert_materials_to_f3d(obj):
    """Build F3D materials without Blender-3.x-only Principled socket names.

    Fast64's general converter accesses Principled 'Subsurface Color', which
    Blender removed in 4.0. This importer handles Blender 4.5 explicitly.
    """
    from fast64.fast64_internal.f3d import f3d_material  # type: ignore

    for index, slot in enumerate(obj.material_slots):
        source = slot.material
        if source is None or bool(getattr(source, "is_f3d", False)):
            continue
        image = find_base_color_image(source)
        category = "Vertex Colored Texture" if image is not None else "Shaded Solid"
        preset = f3d_material.getDefaultMaterialPreset(category)
        converted = f3d_material.createF3DMat(obj, preset=preset, index=index)
        if image is not None:
            converted.f3d_mat.tex0.tex = image
        elif hasattr(converted.f3d_mat, "default_light_color"):
            converted.f3d_mat.default_light_color = source.diffuse_color
        converted.name = source.name + "_f3d"

    unresolved = [
        mat.name for mat in obj.data.materials
        if mat is not None and not bool(getattr(mat, "is_f3d", False))
    ]
    require(not unresolved, f"Fast64 material conversion failed: {unresolved}")


def export_fast64_actor(obj, actors_dir: Path):
    convert_materials_to_f3d(obj)

    scene = bpy.context.scene
    scene.fast64.sm64.exportType = "C"
    if hasattr(scene, "f3d_type"):
        scene.f3d_type = "F3D"
    if hasattr(scene, "isHWv1"):
        scene.isHWv1 = False
    scene.saveTextures = True
    scene.geoSeparateTextureDef = False
    scene.geoCustomExport = True
    scene.geoExportPath = str(actors_dir)
    scene.geoTexDir = "actors/cj/"
    scene.geoName = "cj"
    scene.geoStructName = "cj_geo"
    scene.geoGroupName = "group0"
    scene.geoExportHeaderType = "Actor"
    scene.geoDeleteOldGeo = True
    scene.exportInlineF3D = False
    scene.blenderToSM64Scale = 100.0

    obj.geo_cmd_static = "Optimal"
    obj.draw_layer_static = "1"
    obj.use_render_area = False

    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode="OBJECT")

    result = bpy.ops.object.sm64_export_geolayout_object()
    require("FINISHED" in result, f"Fast64 actor export did not finish: {result}")

    actor_dir = actors_dir / "cj"
    expected = ["geo.inc.c", "model.inc.c", "geo_header.h"]
    missing = [name for name in expected if not (actor_dir / name).is_file()]
    require(not missing, f"Fast64 export did not create expected actor files: {missing}")
    return actor_dir


def copy_mod_scripts(repo_root: Path, mod_root: Path, actor_dir: Path):
    shutil.copy2(repo_root / "main.lua", mod_root / "main.lua")
    shutil.copy2(repo_root / "character.lua", mod_root / "character.lua")
    readme = """# CJ64 — static model test

This package is an **in-game visibility test**, not the final animated CJ model.

- The model is exported as the static DynOS actor `cj_geo`.
- `main.lua` and `character.lua` replace only the visible model on the existing Mario object.
- MarioState, movement, collision, camera and physics are not replaced.
- The mesh has been baked at the FBX rest pose. Limbs will not follow Mario's animation yet.

## Install

Copy this `CJ64-Model-Test` folder into the SM64CoopDX `mods/` directory.
Start the game once; SM64CoopDX should generate the actor `.bin` from the C files
inside `actors/cj/`. Enable the CJ64 mod. The Lua log should report that model
`cj_geo` was registered and applied.

If the model does not appear, remove only the generated `*.bin` inside
`actors/cj/`, restart the game, and inspect the Lua/DynOS error log.

Source model credit: Carl Johnson (CJ) by Tsaphnat (Tsaphnat Mbuyi),
Sketchfab, CC BY 4.0:
https://sketchfab.com/3d-models/carl-johnson-cj-647f5417720344cb8c2079edd48704ac
"""
    (mod_root / "README-INSTALL.txt").write_text(readme, encoding="utf-8")

    actor_readme = """# CJ static test actor

Runtime GeoLayout symbol: `cj_geo`

This first test uses a static display list. It checks model geometry, texture
conversion, DynOS actor generation and native `marioObj` replacement only.
It is not yet weighted to the Mario Armature, so it does not animate.
"""
    (actor_dir / "README.md").write_text(actor_readme, encoding="utf-8")


def make_report(output_root: Path, mod_root: Path, actor_dir: Path, details: dict, obj):
    actor_files = []
    for path in sorted(actor_dir.rglob("*")):
        if path.is_file():
            actor_files.append({
                "path": str(path.relative_to(mod_root)),
                "size": path.stat().st_size,
            })
    report = {
        "format": "cj64-static-model-test-v1",
        "status": "EXPORTED_NOT_YET_TESTED_IN_GAME",
        "model_name": "cj_geo",
        "animation_mode": "STATIC_REST_POSE",
        "keeps_native_mario_object": True,
        "keeps_native_mariostate_physics_collision_camera": True,
        "vertex_count": len(obj.data.vertices),
        "polygon_count": len(obj.data.polygons),
        "material_names": [m.name if m else None for m in obj.data.materials],
        "geometry_alignment": details,
        "actor_files": actor_files,
        "warnings": [
            "This static test has no skinning to the Mario Armature.",
            "Do not judge limb animation from this package; only visual model loading is being tested.",
            "A final actor still needs a validated Mario Armature weight transfer and pose tests.",
        ],
    }
    (output_root / "cj_model_test_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")


def make_zip(mod_root: Path, output_root: Path):
    archive = output_root / "CJ64-Model-Test.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as zf:
        for path in sorted(mod_root.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(mod_root.parent))
    return archive


def main():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(argv) != 3:
        raise SystemExit("usage: export_cj_static_model_test.py <cj.fbx> <repo_root> <output_root>")
    fbx_path, repo_root, output_root = [Path(x).resolve() for x in argv]
    require(fbx_path.is_file(), f"Missing CJ FBX: {fbx_path}")
    require((repo_root / "main.lua").is_file(), "Repository root does not contain main.lua")

    fast64_root = Path(os.environ.get("FAST64_ADDON_PATH", "")).resolve()
    require((fast64_root / "__init__.py").is_file(), "FAST64_ADDON_PATH does not point to the Fast64-Coop add-on")
    sys.path.insert(0, str(fast64_root.parent))
    import fast64  # type: ignore
    fast64.register()

    output_root.mkdir(parents=True, exist_ok=True)
    mod_root = output_root / "CJ64-Model-Test"
    actors_dir = mod_root / "actors"
    actor_dir = actors_dir / "cj"
    actor_dir.mkdir(parents=True, exist_ok=True)

    source_armature, source_meshes = get_source_asset(fbx_path)
    obj = bake_source_rest_meshes(source_armature, source_meshes)
    details = align_and_size_model(obj, source_armature, target_height=1.60)

    # The final mesh no longer depends on the imported GTA armature.
    for imported in list(bpy.context.scene.objects):
        if imported != obj:
            bpy.data.objects.remove(imported, do_unlink=True)

    render_preview(obj, output_root / "CJ64-model-preview.png")
    exported_actor_dir = export_fast64_actor(obj, actors_dir)
    copy_mod_scripts(repo_root, mod_root, exported_actor_dir)
    make_report(output_root, mod_root, exported_actor_dir, details, obj)
    archive = make_zip(mod_root, output_root)

    print(json.dumps({
        "package": str(archive),
        "preview": str(output_root / "CJ64-model-preview.png"),
        "report": str(output_root / "cj_model_test_report.json"),
        "actor_dir": str(exported_actor_dir),
        "dimensions": details["final_dimensions"],
        "actor_files": [str(p.relative_to(mod_root)) for p in sorted(exported_actor_dir.rglob("*")) if p.is_file()],
    }, indent=2))


if __name__ == "__main__":
    main()
