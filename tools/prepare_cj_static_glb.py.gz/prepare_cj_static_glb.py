#!/usr/bin/env python3
"""Import the ASCII CJ FBX in Blender 4.5, bake its rest pose, align and export GLB."""
from __future__ import annotations
import json
import sys
from pathlib import Path
import bpy  # type: ignore
import bmesh  # type: ignore
from mathutils import Matrix, Vector  # type: ignore


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def load_cj_fbx(path: Path):
    # Remove factory-startup cube/camera/light so they are never mistaken for CJ parts.
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.ops.wm.fbx_import(
        filepath=str(path), use_anim=False, use_custom_props=True,
        ignore_leaf_bones=False, validate_meshes=True,
    )
    armatures = [o for o in bpy.context.scene.objects if o.type == "ARMATURE"]
    meshes = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    require(len(armatures) == 1, f"Expected one CJ armature, found {len(armatures)}")
    require(len(meshes) >= 1, f"No CJ mesh objects imported from {path.name}")
    meshes.sort(key=lambda obj: obj.name.casefold())
    print("CJ FBX mesh parts:", [(o.name, len(o.data.vertices), len(o.data.polygons)) for o in meshes])
    return armatures[0], meshes


def bake_rest_meshes(armature, source_meshes):
    armature.data.pose_position = "REST"
    bpy.context.scene.frame_set(0)
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    baked = []
    for source in source_meshes:
        evaluated = source.evaluated_get(depsgraph)
        data = bpy.data.meshes.new_from_object(
            evaluated, preserve_all_data_layers=True, depsgraph=depsgraph
        )
        require(data is not None and len(data.vertices) > 0, f"Empty evaluated mesh: {source.name}")
        obj = bpy.data.objects.new("CJ_Baked__" + source.name, data)
        bpy.context.scene.collection.objects.link(obj)
        obj.matrix_world = source.matrix_world.copy()
        world = obj.matrix_world.copy()
        for vertex in obj.data.vertices:
            vertex.co = world @ vertex.co
        obj.matrix_world = Matrix.Identity(4)
        obj.parent = None
        for modifier in list(obj.modifiers):
            obj.modifiers.remove(modifier)
        while len(obj.vertex_groups):
            obj.vertex_groups.remove(obj.vertex_groups[0])
        obj.data.update()
        baked.append(obj)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in baked:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = baked[0]
    if len(baked) > 1:
        bpy.ops.object.join()
    result = bpy.context.view_layer.objects.active
    result.name = "CJ_Static_Model_Test"
    bm = bmesh.new()
    bm.from_mesh(result.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(result.data)
    bm.free()
    result.data.update()
    return result


def align_and_size(obj, armature, target_height=1.60):
    root = armature.data.bones.get("root ground")
    head = armature.data.bones.get("head neck upper")
    require(root is not None and head is not None, "CJ source skeleton is missing root/head anchor bones")
    root_world = armature.matrix_world @ root.head_local
    head_world = armature.matrix_world @ head.head_local
    up = head_world - root_world
    require(up.length > 0.25, "Invalid CJ root-to-head vector")
    align = up.normalized().rotation_difference(Vector((0.0, 0.0, 1.0)))
    for v in obj.data.vertices:
        v.co = align @ (v.co - root_world)
    height = max(v.co.z for v in obj.data.vertices) - min(v.co.z for v in obj.data.vertices)
    require(height > 0.5, f"Unexpected CJ model height: {height:.4f}")
    factor = target_height / height
    for v in obj.data.vertices:
        v.co *= factor
    min_x = min(v.co.x for v in obj.data.vertices)
    max_x = max(v.co.x for v in obj.data.vertices)
    min_y = min(v.co.y for v in obj.data.vertices)
    max_y = max(v.co.y for v in obj.data.vertices)
    min_z = min(v.co.z for v in obj.data.vertices)
    offset = Vector((-(min_x + max_x) * 0.5, -(min_y + max_y) * 0.5, -min_z))
    for v in obj.data.vertices:
        v.co += offset
    obj.data.update()
    bpy.context.view_layer.update()
    dims = [round(float(x), 5) for x in obj.dimensions]
    require(obj.dimensions.z > obj.dimensions.x * 0.55, f"CJ model orientation looks invalid: {dims}")
    return {
        "source_height": round(float(height), 6),
        "applied_scale": round(float(factor), 6),
        "target_height": float(target_height),
        "final_dimensions": dims,
    }


def render_preview(obj, output_path: Path):
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x = 800
    scene.render.resolution_y = 900
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "Medium High Contrast"
    world = bpy.data.worlds.new("CJ Preview World") if scene.world is None else scene.world
    scene.world = world
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.055, 0.065, 0.085, 1)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.8
    center = Vector((0.0, 0.0, 0.82))
    cam_data = bpy.data.cameras.new("CJ Preview Camera")
    cam = bpy.data.objects.new("CJ Preview Camera", cam_data)
    scene.collection.objects.link(cam)
    cam.location = (2.65, -4.8, 2.15)
    cam_data.type = "ORTHO"
    cam_data.ortho_scale = 2.85
    cam.rotation_euler = (center - cam.location).to_track_quat("-Z", "Y").to_euler()
    scene.camera = cam
    lights = []
    for name, location, power, size in [
        ("Key", (3, -4, 4.2), 650, 4),
        ("Fill", (-3.5, -2, 2.4), 350, 3.2),
        ("Rim", (0.5, 3.5, 3.5), 700, 3),
    ]:
        data = bpy.data.lights.new(name, "AREA")
        data.energy, data.shape, data.size = power, "DISK", size
        light = bpy.data.objects.new(name, data)
        scene.collection.objects.link(light)
        light.location = location
        light.rotation_euler = (center - light.location).to_track_quat("-Z", "Y").to_euler()
        lights.append(light)
    floor_data = bpy.data.meshes.new("Preview Floor Mesh")
    floor_data.from_pydata([(-4,-4,-0.015),(4,-4,-0.015),(4,4,-0.015),(-4,4,-0.015)], [], [(0,1,2,3)])
    floor = bpy.data.objects.new("Preview Floor", floor_data)
    scene.collection.objects.link(floor)
    mat = bpy.data.materials.new("Preview Floor Material")
    mat.diffuse_color = (0.08, 0.09, 0.11, 1)
    floor.data.materials.append(mat)
    scene.render.filepath = str(output_path)
    bpy.ops.render.render(write_still=True)
    bpy.data.objects.remove(floor, do_unlink=True)
    bpy.data.objects.remove(cam, do_unlink=True)
    for light in lights:
        bpy.data.objects.remove(light, do_unlink=True)
    scene.camera = None


def main():
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(args) != 3:
        raise SystemExit("usage: prepare_cj_static_glb.py <source.fbx> <repo_root> <output_dir>")
    fbx, repo_root, output = [Path(x).resolve() for x in args]
    require(fbx.is_file(), f"Missing CJ FBX: {fbx}")
    require((repo_root / "main.lua").is_file(), "Repo root missing main.lua")
    output.mkdir(parents=True, exist_ok=True)
    armature, parts = load_cj_fbx(fbx)
    obj = bake_rest_meshes(armature, parts)
    geometry = align_and_size(obj, armature)
    for other in list(bpy.context.scene.objects):
        if other != obj:
            bpy.data.objects.remove(other, do_unlink=True)
    render_preview(obj, output / "CJ64-model-preview.png")
    try:
        bpy.ops.preferences.addon_enable(module="io_scene_gltf2")
    except Exception:
        pass
    require(hasattr(bpy.ops.export_scene, "gltf"), "Blender glTF exporter is unavailable")
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    glb = output / "CJ-Static-Model.glb"
    result = bpy.ops.export_scene.gltf(
        filepath=str(glb), export_format="GLB", use_selection=True,
        export_apply=True, export_image_format="AUTO",
    )
    require("FINISHED" in result and glb.is_file() and glb.stat().st_size > 10000,
            f"GLB export failed: {result}")
    report = {
        "format": "cj64-static-prepared-glb-v1",
        "status": "PREPARED_FOR_FAST64_EXPORT",
        "vertex_count": len(obj.data.vertices),
        "polygon_count": len(obj.data.polygons),
        "material_names": [m.name if m else None for m in obj.data.materials],
        "geometry_alignment": geometry,
        "glb_size": glb.stat().st_size,
    }
    (output / "cj_static_glb_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"glb": str(glb), "preview": str(output / "CJ64-model-preview.png"),
                      "report": report}, indent=2))


if __name__ == "__main__":
    main()
